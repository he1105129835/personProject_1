//
//  HNPYZCreatCell.h
//  HNPGameApp
//
//  Created by henanping on 2020/7/2.
//  Copyright © 2020 何南平. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface HNPYZCreatCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *TeamImageView_1;
@property (weak, nonatomic) IBOutlet UIImageView *TeamIamgeView_2;
@property (weak, nonatomic) IBOutlet UILabel *TeamName_1;
@property (weak, nonatomic) IBOutlet UILabel *TeamName_2;

@end

NS_ASSUME_NONNULL_END
