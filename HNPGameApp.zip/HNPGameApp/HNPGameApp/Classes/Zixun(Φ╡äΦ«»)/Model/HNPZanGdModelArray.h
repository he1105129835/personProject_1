//
//  HNPZanGdModelArray.h
//  HNPGameApp
//
//  Created by henanping on 2020/7/16.
//  Copyright © 2020 何南平. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface HNPZanGdModelArray : NSObject<NSCoding>

@property (strong, nonatomic) NSMutableArray *zanGdArray;

@end

NS_ASSUME_NONNULL_END
