//
//  HNPZanGdModel.h
//  HNPGameApp
//
//  Created by henanping on 2020/7/16.
//  Copyright © 2020 何南平. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface HNPZanGdModel : NSObject<NSCoding>

@property (nonatomic,strong) NSString *neirongImageView;
@property (nonatomic,strong) NSString *neirongLable;

@end

NS_ASSUME_NONNULL_END
