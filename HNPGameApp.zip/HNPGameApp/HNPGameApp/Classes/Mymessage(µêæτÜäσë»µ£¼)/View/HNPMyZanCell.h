//
//  HNPMyZanCell.h
//  HNPGameApp
//
//  Created by henanping on 2020/7/3.
//  Copyright © 2020 何南平. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HNPZanGdModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface HNPMyZanCell : UITableViewCell

@property (nonatomic,strong)HNPZanGdModel *ZanGdM;

@end

NS_ASSUME_NONNULL_END
