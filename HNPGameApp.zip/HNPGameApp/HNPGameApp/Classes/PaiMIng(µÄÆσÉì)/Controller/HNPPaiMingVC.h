//
//  HNPPaiMingVC.h
//  HNPGameApp
//
//  Created by henanping on 2020/6/29.
//  Copyright © 2020 何南平. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <FSScrollContentView.h>

NS_ASSUME_NONNULL_BEGIN

@interface HNPPaiMingVC : UIViewController

//顶部控制器的标题
@property (nonatomic ,strong)FSSegmentTitleView *titleView;

@end

NS_ASSUME_NONNULL_END
